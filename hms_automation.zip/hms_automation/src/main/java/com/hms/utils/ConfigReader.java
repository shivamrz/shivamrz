package com.hms.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * ConfigReader
 * -------------------------------------------------------------------
 * Reads all key-value pairs from config.properties ONCE (static block)
 * and exposes them via typed getter methods.
 *
 * SDET Best Practice:
 *   - Centralise all config here. Test code never hardcodes values.
 *   - Throwing RuntimeException on load failure fails fast with a clear message.
 * -------------------------------------------------------------------
 */
public class ConfigReader {

    private static final Properties properties = new Properties();
    private static final String CONFIG_PATH = "src/main/resources/config.properties";

    // Static initialiser: loads file once when class is first referenced
    static {
        try (FileInputStream fis = new FileInputStream(CONFIG_PATH)) {
            properties.load(fis);
        } catch (IOException e) {
            throw new RuntimeException(
                "FATAL: config.properties not found at: " + CONFIG_PATH, e);
        }
    }

    // ── Application ──────────────────────────────────────────────────

    /** Base URL of the HMS application (login page). */
    public static String getAppUrl() {
        return properties.getProperty("app.url");
    }

    // ── Browser / Driver ─────────────────────────────────────────────

    /** Browser name, e.g. "chrome". */
    public static String getBrowser() {
        return properties.getProperty("browser");
    }

    /** Absolute path to the local chromedriver.exe file. */
    public static String getChromedriverPath() {
        return properties.getProperty("chromedriver.path");
    }

    // ── Credentials ──────────────────────────────────────────────────

    public static String getValidUsername() {
        return properties.getProperty("valid.username");
    }

    public static String getValidPassword() {
        return properties.getProperty("valid.password");
    }

    public static String getInvalidUsername() {
        return properties.getProperty("invalid.username");
    }

    public static String getInvalidPassword() {
        return properties.getProperty("invalid.password");
    }

    // ── Test Data ────────────────────────────────────────────────────

    /** Patient ID that has existing cases (e.g. "12"). */
    public static String getTestPatientId() {
        return properties.getProperty("test.patientId");
    }

    /** Case ID to select for subscription / blood request tests. */
    public static String getTestCaseId() {
        return properties.getProperty("test.caseId");
    }

    /** Case ID that has NO subscription — for negative fetch tests. */
    public static String getNoSubscriptionCaseId() {
        return properties.getProperty("test.noSubscriptionCaseId");
    }

    // ── Waits ────────────────────────────────────────────────────────

    /** Implicit wait in seconds (applied globally on driver). */
    public static int getImplicitWait() {
        return Integer.parseInt(properties.getProperty("implicit.wait"));
    }

    /** Explicit wait in seconds (used in WebDriverWait calls). */
    public static int getExplicitWait() {
        return Integer.parseInt(properties.getProperty("explicit.wait"));
    }
}
