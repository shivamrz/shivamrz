package com.hms.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.io.File;

/**
 * BaseTest
 * -------------------------------------------------------------------
 * Parent class for ALL test classes. Every test class extends this.
 *
 * Responsibilities:
 *   1. Configure Log4j2 before anything else (static block runs first).
 *   2. Create logs/ directory if it does not exist.
 *   3. @BeforeMethod — open browser, navigate to app.
 *   4. @AfterMethod  — quit browser regardless of pass/fail.
 *
 * SDET Best Practice:
 *   - Tests should never open/close browsers themselves.
 *   - All shared setup/teardown lives here — DRY principle.
 * -------------------------------------------------------------------
 */
public class BaseTest {

    // protected: accessible in all subclasses (test classes)
    protected static final Logger log;

    static {
        // Must set config path BEFORE LogManager is ever called.
        // Eclipse/Maven look for log4j2.xml from the project working directory.
        System.setProperty(
            "log4j2.configurationFile",
            "src/main/resources/log4j2.xml"
        );

        // Create logs/ folder in project root so FileAppender can write
        File logsDir = new File("logs");
        if (!logsDir.exists()) {
            logsDir.mkdirs();
            System.out.println("[INFO] Created logs/ directory at: " + logsDir.getAbsolutePath());
        }

        // Initialise logger — config is guaranteed set before this line
        log = LogManager.getLogger(BaseTest.class);
        log.info("Log4j2 initialised. Log file: " + logsDir.getAbsolutePath() + "/hms-test.log");
    }

    /**
     * Runs BEFORE every @Test method.
     * Opens a fresh browser and lands on the login page.
     */
    @BeforeMethod
    public void setUp() {
        log.info("========== TEST SETUP STARTED ==========");
        DriverSetup.initDriver();
        DriverSetup.openApp();
        log.info("Application ready at: " + ConfigReader.getAppUrl());
    }

    /**
     * Runs AFTER every @Test method (pass or fail).
     * Closes the browser to free resources.
     */
    @AfterMethod
    public void tearDown() {
        DriverSetup.quitDriver();
        log.info("========== TEST TEARDOWN COMPLETE ==========\n");
    }
}
