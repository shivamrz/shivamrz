package com.hms.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.util.concurrent.TimeUnit;

/**
 * DriverSetup
 * -------------------------------------------------------------------
 * Creates and destroys the WebDriver instance.
 *
 * SDET Best Practices applied:
 *   - ThreadLocal<WebDriver>: each thread gets its own driver instance,
 *     making the framework safe for parallel test execution later.
 *   - Local chromedriver path from config — no WebDriverManager dependency.
 *   - ChromeOptions suppress cert/info-bar popups that block elements.
 *   - remove() in quitDriver() prevents memory leaks in long runs.
 * -------------------------------------------------------------------
 */
public class DriverSetup {

    private static final Logger log = LogManager.getLogger(DriverSetup.class);

    // ThreadLocal: isolates driver per thread (safe for parallel runs)
    private static final ThreadLocal<WebDriver> driverThread = new ThreadLocal<>();

    /**
     * Initialises ChromeDriver using path from config.properties.
     * Called in BaseTest @BeforeMethod so every test gets a fresh browser.
     */
    public static void initDriver() {

        String browser = ConfigReader.getBrowser();
        log.info("Initialising browser: " + browser);

        if (browser.equalsIgnoreCase("chrome")) {

            // Read local chromedriver path — update config.properties, not this file
            String driverPath = ConfigReader.getChromedriverPath();
            System.setProperty("webdriver.chrome.driver", driverPath);
            log.info("ChromeDriver path: " + driverPath);

            ChromeOptions options = new ChromeOptions();
            // Suppress SSL certificate error popups
            options.addArguments("--ignore-certificate-errors");
            // Remove "Chrome is being controlled by automated software" bar
            options.addArguments("--disable-infobars");
            // Disable save-password prompts
            options.addArguments("--disable-save-password-bubble");

            driverThread.set(new ChromeDriver(options));
            log.info("ChromeDriver started successfully.");

        } else {
            log.error("Unsupported browser: '" + browser + "'. Only 'chrome' is configured.");
            throw new RuntimeException("Unsupported browser: " + browser);
        }

        // Maximise so all elements are visible and consistent across screen sizes
        driverThread.get().manage().window().maximize();

        // Implicit wait: every findElement() waits up to N seconds before throwing
        driverThread.get().manage().timeouts()
                .implicitlyWait(ConfigReader.getImplicitWait(), TimeUnit.SECONDS);

        log.info("Browser maximised. Implicit wait: " + ConfigReader.getImplicitWait() + "s.");
    }

    /**
     * Returns the WebDriver for the current thread.
     * All Page Objects and test classes call this to interact with the browser.
     */
    public static WebDriver getDriver() {
        return driverThread.get();
    }

    /**
     * Navigates to the app URL defined in config.properties.
     */
    public static void openApp() {
        String url = ConfigReader.getAppUrl();
        log.info("Navigating to: " + url);
        driverThread.get().get(url);
    }

    /**
     * Quits the browser and removes driver from ThreadLocal.
     * Called in BaseTest @AfterMethod so no orphaned browser processes remain.
     */
    public static void quitDriver() {
        if (driverThread.get() != null) {
            log.info("Closing browser.");
            driverThread.get().quit();
            driverThread.remove(); // prevent memory leak
        }
    }
}
