package com.hms.tests;

import com.hms.pages.HomePage;
import com.hms.pages.LoginPage;
import com.hms.utils.BaseTest;
import com.hms.utils.ConfigReader;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * LoginTests
 * -------------------------------------------------------------------
 * Covers RQ_1 — Login Page (TC_Login_001 to TC_Login_007)
 *
 * Each @Test is independent: BaseTest opens a fresh browser before it
 * and closes it after it via @BeforeMethod / @AfterMethod.
 *
 * SDET Best Practices:
 *   - Test IDs in method names for traceability to the test case sheet.
 *   - Assert messages describe WHAT failed, not just that it failed.
 *   - Credentials always come from ConfigReader, never hardcoded.
 * -------------------------------------------------------------------
 */
public class LoginTests extends BaseTest {

    // ── TC_Login_001 ──────────────────────────────────────────────────

    /**
     * TC_Login_001 | GUI
     * Verify all expected UI elements are displayed on the Login page.
     */
    @Test(description = "TC_Login_001 - Verify Login page GUI elements are displayed")
    public void tc_Login_001_verifyLoginPageGUIElements() {
        log.info(">>> TC_Login_001: Verifying Login page GUI elements.");

        LoginPage loginPage = new LoginPage();

        Assert.assertTrue(loginPage.isUserIdFieldDisplayed(),
            "TC_Login_001 FAIL: User ID field is not displayed.");

        Assert.assertTrue(loginPage.isPasswordFieldDisplayed(),
            "TC_Login_001 FAIL: Password field is not displayed.");

        Assert.assertTrue(loginPage.isLoginButtonDisplayed(),
            "TC_Login_001 FAIL: Login button is not displayed.");

        Assert.assertTrue(loginPage.isResetButtonDisplayed(),
            "TC_Login_001 FAIL: Reset button is not displayed.");

        log.info("<<< TC_Login_001 PASS: All Login page GUI elements displayed.");
    }

    // ── TC_Login_002 ──────────────────────────────────────────────────

    /**
     * TC_Login_002 | GUI
     * Verify Password field masks entered characters (type="password").
     */
    @Test(description = "TC_Login_002 - Verify Password field masks entered characters")
    public void tc_Login_002_verifyPasswordFieldMasksInput() {
        log.info(">>> TC_Login_002: Verifying password field masking.");

        LoginPage loginPage = new LoginPage();
        loginPage.enterPassword("abc123");

        Assert.assertTrue(loginPage.isPasswordMasked(),
            "TC_Login_002 FAIL: Password field does not mask characters (type != 'password').");

        log.info("<<< TC_Login_002 PASS: Password field correctly masks input.");
    }

    // ── TC_Login_003 ──────────────────────────────────────────────────

    /**
     * TC_Login_003 | Mandatory
     * Verify mandatory validation when both User ID and Password are empty.
     */
    @Test(description = "TC_Login_003 - Verify mandatory validation when both fields are empty")
    public void tc_Login_003_verifyMandatoryValidationBothFieldsEmpty() {
        log.info(">>> TC_Login_003: Submitting login with both fields empty.");

        LoginPage loginPage = new LoginPage();
        loginPage.clickLogin(); // both fields empty

        // User must remain on login page
        Assert.assertTrue(loginPage.isOnLoginPage(),
            "TC_Login_003 FAIL: User was not kept on the login page after empty submit.");

        // A validation message must appear
        String validationMsg = loginPage.getValidationMessage();
        Assert.assertFalse(validationMsg.isEmpty(),
            "TC_Login_003 FAIL: No validation message displayed for empty fields.");

        log.info("<<< TC_Login_003 PASS: Validation shown, user stays on login page. Msg: '"
                 + validationMsg + "'");
    }

    // ── TC_Login_004 ──────────────────────────────────────────────────

    /**
     * TC_Login_004 | Mandatory
     * Verify mandatory validation when User ID is empty and Password is filled.
     */
    @Test(description = "TC_Login_004 - Verify mandatory validation when only User ID is empty")
    public void tc_Login_004_verifyMandatoryValidationUserIdEmpty() {
        log.info(">>> TC_Login_004: Submitting login with User ID empty.");

        LoginPage loginPage = new LoginPage();
        loginPage.enterPassword(ConfigReader.getValidPassword()); // password filled
        loginPage.clickLogin();                                    // user ID blank

        Assert.assertTrue(loginPage.isOnLoginPage(),
            "TC_Login_004 FAIL: User navigated away despite empty User ID.");

        String validationMsg = loginPage.getValidationMessage();
        Assert.assertFalse(validationMsg.isEmpty(),
            "TC_Login_004 FAIL: No validation message for missing User ID.");

        log.info("<<< TC_Login_004 PASS: Validation shown for missing User ID. Msg: '"
                 + validationMsg + "'");
    }

    // ── TC_Login_005 ──────────────────────────────────────────────────

    /**
     * TC_Login_005 | Valid
     * Verify successful login with valid credentials redirects to dashboard.
     */
    @Test(description = "TC_Login_005 - Verify successful login with valid credentials")
    public void tc_Login_005_verifySuccessfulLogin() {
        log.info(">>> TC_Login_005: Logging in with valid credentials.");

        LoginPage loginPage = new LoginPage();
        loginPage.login(ConfigReader.getValidUsername(), ConfigReader.getValidPassword());

        HomePage homePage = new HomePage();
        Assert.assertTrue(homePage.isLoaded(),
            "TC_Login_005 FAIL: User was NOT redirected to the dashboard after valid login.");

        log.info("<<< TC_Login_005 PASS: Successful login, dashboard loaded.");
    }

    // ── TC_Login_006 ──────────────────────────────────────────────────

    /**
     * TC_Login_006 | Valid
     * Verify login fails and error message shown with invalid password.
     */
    @Test(description = "TC_Login_006 - Verify login fails with invalid password")
    public void tc_Login_006_verifyLoginFailsWithInvalidPassword() {
        log.info(">>> TC_Login_006: Logging in with valid User ID but wrong password.");

        LoginPage loginPage = new LoginPage();
        loginPage.login(ConfigReader.getValidUsername(), ConfigReader.getInvalidPassword());

        Assert.assertTrue(loginPage.isOnLoginPage(),
            "TC_Login_006 FAIL: User was redirected away despite invalid password.");

        String errorMsg = loginPage.getValidationMessage();
        Assert.assertFalse(errorMsg.isEmpty(),
            "TC_Login_006 FAIL: No error message shown for invalid password.");

        log.info("<<< TC_Login_006 PASS: Login blocked, error shown. Msg: '" + errorMsg + "'");
    }

    // ── TC_Login_007 ──────────────────────────────────────────────────

    /**
     * TC_Login_007 | Button
     * Verify Reset button clears both User ID and Password fields.
     */
    @Test(description = "TC_Login_007 - Verify Reset button clears all login fields")
    public void tc_Login_007_verifyResetButtonClearsFields() {
        log.info(">>> TC_Login_007: Entering values then clicking Reset.");

        LoginPage loginPage = new LoginPage();
        loginPage.enterUserId(ConfigReader.getValidUsername());
        loginPage.enterPassword(ConfigReader.getValidPassword());
        loginPage.clickReset();

        Assert.assertEquals(loginPage.getUserIdFieldValue(), "",
            "TC_Login_007 FAIL: User ID field was NOT cleared after Reset.");

        Assert.assertEquals(loginPage.getPasswordFieldValue(), "",
            "TC_Login_007 FAIL: Password field was NOT cleared after Reset.");

        log.info("<<< TC_Login_007 PASS: Both fields cleared by Reset.");
    }
}
