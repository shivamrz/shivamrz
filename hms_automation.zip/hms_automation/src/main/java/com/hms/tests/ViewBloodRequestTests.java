package com.hms.tests;

import com.hms.pages.LoginPage;
import com.hms.pages.ViewBloodRequestPage;
import com.hms.utils.BaseTest;
import com.hms.utils.ConfigReader;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * ViewBloodRequestTests
 * -------------------------------------------------------------------
 * Covers RQ_5 — Blood > Requests > View Blood Requests (TC_VBR_001..005)
 * -------------------------------------------------------------------
 */
public class ViewBloodRequestTests extends BaseTest {

    // ── Shared helper ─────────────────────────────────────────────────

    /**
     * Logs in and navigates to View Blood Requests tab.
     * TODO: Replace with actual menu navigation once HMS locators are known.
     */
    private ViewBloodRequestPage loginAndNavigate() {
        log.info("Precondition: Logging in and navigating to View Blood Requests page.");
        new LoginPage().login(ConfigReader.getValidUsername(), ConfigReader.getValidPassword());
        // TODO: e.g. new HomePage().clickBloodMenu(); new HomePage().clickViewBloodRequestsTab();
        return new ViewBloodRequestPage();
    }

    // ── TC_VBR_001 ────────────────────────────────────────────────────

    /**
     * TC_VBR_001 | GUI
     * Verify View Blood Requests page displays all expected UI elements.
     */
    @Test(description = "TC_VBR_001 - Verify View Blood Requests page GUI elements")
    public void tc_VBR_001_verifyPageGUIElements() {
        log.info(">>> TC_VBR_001: Verifying View Blood Requests GUI elements.");

        ViewBloodRequestPage page = loginAndNavigate();

        Assert.assertTrue(page.isPageLoaded(),
            "TC_VBR_001 FAIL: One or more expected GUI elements are missing.");

        log.info("<<< TC_VBR_001 PASS: All View Blood Requests GUI elements present.");
    }

    // ── TC_VBR_002 ────────────────────────────────────────────────────

    /**
     * TC_VBR_002 | Button
     * Verify Search button fetches the case list for Patient ID 12.
     */
    @Test(description = "TC_VBR_002 - Verify Search button fetches case list")
    public void tc_VBR_002_verifySearchFetchesCaseList() {
        log.info(">>> TC_VBR_002: Searching Patient ID: " + ConfigReader.getTestPatientId());

        ViewBloodRequestPage page = loginAndNavigate();
        page.searchPatient(ConfigReader.getTestPatientId());

        Assert.assertTrue(page.isCaseTablePopulated(),
            "TC_VBR_002 FAIL: Case table NOT populated after Search for Patient ID "
            + ConfigReader.getTestPatientId());

        log.info("<<< TC_VBR_002 PASS: Case table populated after Search.");
    }

    // ── TC_VBR_003 ────────────────────────────────────────────────────

    /**
     * TC_VBR_003 | Button
     * Verify Fetch Blood Requests returns results for selected case (Case 12).
     */
    @Test(description = "TC_VBR_003 - Verify Fetch Blood Requests returns results for selected case")
    public void tc_VBR_003_verifyFetchBloodRequestsReturnsResults() {
        log.info(">>> TC_VBR_003: Fetching blood requests for Case ID "
                 + ConfigReader.getTestCaseId());

        ViewBloodRequestPage page = loginAndNavigate();
        page.searchPatient(ConfigReader.getTestPatientId());
        page.selectFirstCaseFromTable();
        page.clickFetchBloodRequests();

        Assert.assertTrue(page.isResultsTablePopulated(),
            "TC_VBR_003 FAIL: Results table NOT populated after Fetch Blood Requests.");

        log.info("<<< TC_VBR_003 PASS: Blood request results loaded in table.");
    }

    // ── TC_VBR_004 ────────────────────────────────────────────────────

    /**
     * TC_VBR_004 | Valid
     * Verify no records shown for a case with no blood requests (Patient/Case 99).
     */
    @Test(description = "TC_VBR_004 - Verify no records shown for case with no blood requests")
    public void tc_VBR_004_verifyNoRecordsForCaseWithNoRequests() {
        log.info(">>> TC_VBR_004: Fetching requests for Patient/Case with no blood requests: "
                 + ConfigReader.getNoSubscriptionCaseId());

        ViewBloodRequestPage page = loginAndNavigate();
        page.searchPatient(ConfigReader.getNoSubscriptionCaseId());
        page.selectFirstCaseFromTable();
        page.clickFetchBloodRequests();

        Assert.assertTrue(page.isResultsTableEmpty(),
            "TC_VBR_004 FAIL: Results table shows records for a case that has none.");

        log.info("<<< TC_VBR_004 PASS: Results table correctly empty for case with no requests.");
    }

    // ── TC_VBR_005 ────────────────────────────────────────────────────

    /**
     * TC_VBR_005 | Button
     * Verify Reset button clears all View Blood Requests fields and results.
     */
    @Test(description = "TC_VBR_005 - Verify Reset button clears all fields")
    public void tc_VBR_005_verifyResetClearsAllFields() {
        log.info(">>> TC_VBR_005: Fetching records then clicking Reset.");

        ViewBloodRequestPage page = loginAndNavigate();
        page.searchPatient(ConfigReader.getTestPatientId());
        page.selectFirstCaseFromTable();
        page.clickFetchBloodRequests();

        // Now reset
        page.clickReset();

        Assert.assertTrue(page.areFieldsCleared(),
            "TC_VBR_005 FAIL: Fields were NOT cleared after clicking Reset.");

        log.info("<<< TC_VBR_005 PASS: All fields cleared after Reset.");
    }
}
