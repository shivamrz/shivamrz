package com.hms.tests;

import com.hms.pages.AddBloodRequestPage;
import com.hms.pages.LoginPage;
import com.hms.utils.BaseTest;
import com.hms.utils.ConfigReader;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * AddBloodRequestTests
 * -------------------------------------------------------------------
 * Covers RQ_4 — Blood > Requests > Add Blood Requests (TC_ABR_001..009)
 *
 * Precondition for TC_ABR_004..009: Patient 12 must have
 * Blood Request service subscribed (TC_SS_006 must have run, or the
 * subscription must exist in the database before running these tests).
 * -------------------------------------------------------------------
 */
public class AddBloodRequestTests extends BaseTest {

    // ── Shared helper ─────────────────────────────────────────────────

    /**
     * Logs in and navigates to the Add Blood Requests tab.
     * TODO: Replace with actual navigation steps once HMS menu locators are known.
     */
    private AddBloodRequestPage loginAndNavigate() {
        log.info("Precondition: Logging in and navigating to Add Blood Requests page.");
        new LoginPage().login(ConfigReader.getValidUsername(), ConfigReader.getValidPassword());
        // TODO: e.g. new HomePage().clickBloodMenu(); new HomePage().clickAddBloodRequestsTab();
        return new AddBloodRequestPage();
    }

    // ── TC_ABR_001 ────────────────────────────────────────────────────

    /**
     * TC_ABR_001 | GUI
     * Verify Add Blood Requests page displays all expected UI elements.
     */
    @Test(description = "TC_ABR_001 - Verify Add Blood Requests page GUI elements")
    public void tc_ABR_001_verifyPageGUIElements() {
        log.info(">>> TC_ABR_001: Verifying Add Blood Requests GUI elements.");

        AddBloodRequestPage page = loginAndNavigate();

        Assert.assertTrue(page.isPageLoaded(),
            "TC_ABR_001 FAIL: One or more expected GUI elements are missing.");

        log.info("<<< TC_ABR_001 PASS: All Add Blood Requests GUI elements present.");
    }

    // ── TC_ABR_002 ────────────────────────────────────────────────────

    /**
     * TC_ABR_002 | Button
     * Verify Search button fetches the case list for Patient ID 12.
     */
    @Test(description = "TC_ABR_002 - Verify Search fetches case list for given PatientID")
    public void tc_ABR_002_verifySearchFetchesCaseList() {
        log.info(">>> TC_ABR_002: Searching Patient ID: " + ConfigReader.getTestPatientId());

        AddBloodRequestPage page = loginAndNavigate();
        page.searchPatient(ConfigReader.getTestPatientId());

        Assert.assertTrue(page.isCaseTablePopulated(),
            "TC_ABR_002 FAIL: Case table NOT populated after Search for Patient ID "
            + ConfigReader.getTestPatientId());

        log.info("<<< TC_ABR_002 PASS: Case table populated after Search.");
    }

    // ── TC_ABR_003 ────────────────────────────────────────────────────

    /**
     * TC_ABR_003 | Button
     * Verify Select button auto-fills the CaseID mandatory field.
     */
    @Test(description = "TC_ABR_003 - Verify Select button auto-fills CaseID")
    public void tc_ABR_003_verifySelectAutoFillsCaseId() {
        log.info(">>> TC_ABR_003: Verifying Select auto-populates CaseID.");

        AddBloodRequestPage page = loginAndNavigate();
        page.searchPatient(ConfigReader.getTestPatientId());
        page.selectFirstCaseFromTable();

        String caseId = page.getCaseIdFieldValue();
        Assert.assertFalse(caseId.isEmpty(),
            "TC_ABR_003 FAIL: CaseID field was NOT auto-filled after clicking Select.");

        log.info("<<< TC_ABR_003 PASS: CaseID auto-filled with: " + caseId);
    }

    // ── TC_ABR_004 ────────────────────────────────────────────────────

    /**
     * TC_ABR_004 | Button
     * Verify Fetch Service Subscription populates the dropdown with subscribed services.
     */
    @Test(description = "TC_ABR_004 - Verify Fetch Service Subscription loads dropdown")
    public void tc_ABR_004_verifyFetchServiceSubscriptionLoadsDropdown() {
        log.info(">>> TC_ABR_004: Fetching service subscriptions for Case ID "
                 + ConfigReader.getTestCaseId());

        AddBloodRequestPage page = loginAndNavigate();
        page.searchPatient(ConfigReader.getTestPatientId());
        page.selectFirstCaseFromTable();
        page.clickFetchServiceSubscription();

        Assert.assertTrue(page.isServiceSubscriptionDropdownPopulated(),
            "TC_ABR_004 FAIL: Service Subscription dropdown NOT populated after Fetch.");

        log.info("<<< TC_ABR_004 PASS: Service Subscription dropdown loaded.");
    }

    // ── TC_ABR_005 ────────────────────────────────────────────────────

    /**
     * TC_ABR_005 | Drop Down
     * Verify Unit Size and No Of Units dropdowns are selectable.
     */
    @Test(description = "TC_ABR_005 - Verify Unit Size and No Of Units dropdowns are selectable")
    public void tc_ABR_005_verifyDropdownsAreSelectable() {
        log.info(">>> TC_ABR_005: Testing Unit Size and No Of Units dropdowns.");

        AddBloodRequestPage page = loginAndNavigate();
        page.searchPatient(ConfigReader.getTestPatientId());
        page.selectFirstCaseFromTable();
        page.clickFetchServiceSubscription();
        page.selectServiceSubscription("Blood Request");

        page.selectUnitSize("500ml");
        page.selectNoOfUnits("2");

        Assert.assertEquals(page.getSelectedUnitSize(), "500ml",
            "TC_ABR_005 FAIL: Unit Size selection did not register '500ml'.");

        Assert.assertEquals(page.getSelectedNoOfUnits(), "2",
            "TC_ABR_005 FAIL: No Of Units selection did not register '2'.");

        log.info("<<< TC_ABR_005 PASS: Both dropdowns accept and retain selections.");
    }

    // ── TC_ABR_006 ────────────────────────────────────────────────────

    /**
     * TC_ABR_006 | Mandatory
     * Verify validation shown when PatientID is blank on Search.
     */
    @Test(description = "TC_ABR_006 - Verify mandatory validation when PatientID is blank on Search")
    public void tc_ABR_006_verifyMandatoryValidationPatientIdBlank() {
        log.info(">>> TC_ABR_006: Clicking Search with PatientID field empty.");

        AddBloodRequestPage page = loginAndNavigate();
        // Deliberately leave PatientID blank
        page.searchPatient(""); // empty string — no Patient ID entered

        String validationMsg = page.getValidationMessage();
        Assert.assertFalse(validationMsg.isEmpty(),
            "TC_ABR_006 FAIL: No validation message for blank PatientID on Search.");

        // Confirm no cases were loaded
        Assert.assertFalse(page.isCaseTablePopulated(),
            "TC_ABR_006 FAIL: Case table populated despite blank PatientID.");

        log.info("<<< TC_ABR_006 PASS: Validation shown for blank PatientID. Msg: '"
                 + validationMsg + "'");
    }

    // ── TC_ABR_007 ────────────────────────────────────────────────────

    /**
     * TC_ABR_007 | Mandatory
     * Verify validation shown when CaseID is blank on Fetch Service Subscription.
     */
    @Test(description = "TC_ABR_007 - Verify mandatory validation when CaseID is blank on Fetch")
    public void tc_ABR_007_verifyMandatoryValidationCaseIdBlank() {
        log.info(">>> TC_ABR_007: Clicking Fetch with CaseID field empty.");

        AddBloodRequestPage page = loginAndNavigate();
        // Skip searchPatient and selectCase so CaseID remains blank
        page.clickFetchServiceSubscription();

        String validationMsg = page.getValidationMessage();
        Assert.assertFalse(validationMsg.isEmpty(),
            "TC_ABR_007 FAIL: No validation message for blank CaseID on Fetch.");

        Assert.assertFalse(page.isServiceSubscriptionDropdownPopulated(),
            "TC_ABR_007 FAIL: Service Subscription dropdown populated despite blank CaseID.");

        log.info("<<< TC_ABR_007 PASS: Validation shown for blank CaseID. Msg: '"
                 + validationMsg + "'");
    }

    // ── TC_ABR_008 ────────────────────────────────────────────────────

    /**
     * TC_ABR_008 | Valid
     * Verify successful Blood Request submission with all valid inputs.
     */
    @Test(description = "TC_ABR_008 - Verify successful Blood Request submission")
    public void tc_ABR_008_verifySuccessfulBloodRequestSubmission() {
        log.info(">>> TC_ABR_008: Submitting a complete Blood Request for Patient "
                 + ConfigReader.getTestPatientId());

        AddBloodRequestPage page = loginAndNavigate();
        page.searchPatient(ConfigReader.getTestPatientId());
        page.selectFirstCaseFromTable();
        page.clickFetchServiceSubscription();
        page.selectServiceSubscription("Blood Request");
        page.selectUnitSize("500ml");
        page.selectNoOfUnits("2");
        page.clickAddBloodRequest();

        Assert.assertTrue(page.isSuccessMessageDisplayed(),
            "TC_ABR_008 FAIL: Success message NOT shown after valid Blood Request submission.");

        log.info("<<< TC_ABR_008 PASS: Blood Request submitted successfully.");
    }

    // ── TC_ABR_009 ────────────────────────────────────────────────────

    /**
     * TC_ABR_009 | Valid
     * Verify Fetch Service Subscription returns empty for case with no subscription.
     */
    @Test(description = "TC_ABR_009 - Verify empty dropdown for case with no subscription")
    public void tc_ABR_009_verifyEmptyDropdownForUnsubscribedCase() {
        log.info(">>> TC_ABR_009: Fetching subscriptions for unsubscribed Case ID "
                 + ConfigReader.getNoSubscriptionCaseId());

        AddBloodRequestPage page = loginAndNavigate();
        // Search patient 99 which has no subscription
        page.searchPatient(ConfigReader.getNoSubscriptionCaseId());
        page.selectFirstCaseFromTable();
        page.clickFetchServiceSubscription();

        Assert.assertTrue(page.isServiceSubscriptionDropdownEmpty(),
            "TC_ABR_009 FAIL: Service Subscription dropdown is NOT empty for unsubscribed case.");

        log.info("<<< TC_ABR_009 PASS: Dropdown correctly empty for unsubscribed case.");
    }
}
