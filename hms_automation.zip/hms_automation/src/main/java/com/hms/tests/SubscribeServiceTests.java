package com.hms.tests;

import com.hms.pages.LoginPage;
import com.hms.pages.SubscribeServicePage;
import com.hms.utils.BaseTest;
import com.hms.utils.ConfigReader;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * SubscribeServiceTests
 * -------------------------------------------------------------------
 * Covers RQ_3 — Patient > Subscribe Service (TC_SS_001 to TC_SS_006)
 *
 * Precondition for all tests: login as admin and navigate to the
 * Subscribe Service tab. Navigation is done inline per test since
 * BaseTest only lands on the login page.
 *
 * NOTE: Update the navigation steps (navigateToSubscribeService())
 *       once the actual menu link/tab locators are identified on HMS.
 * -------------------------------------------------------------------
 */
public class SubscribeServiceTests extends BaseTest {

    // ── Shared helper ─────────────────────────────────────────────────

    /**
     * Logs in and navigates to Patient > Subscribe Service tab.
     * Called at the top of each test as a precondition.
     *
     * TODO: Replace with the actual navigation steps once HMS locators are known.
     *       e.g. click "Patient" menu → click "Subscribe Service" tab.
     */
    private SubscribeServicePage loginAndNavigate() {
        log.info("Precondition: Logging in and navigating to Subscribe Service page.");
        new LoginPage().login(ConfigReader.getValidUsername(), ConfigReader.getValidPassword());
        // TODO: Add real navigation clicks here, e.g.:
        // new HomePage().clickPatientMenu();
        // new HomePage().clickSubscribeServiceTab();
        return new SubscribeServicePage();
    }

    // ── TC_SS_001 ─────────────────────────────────────────────────────

    /**
     * TC_SS_001 | GUI
     * Verify Subscribe Service page displays all expected UI elements.
     */
    @Test(description = "TC_SS_001 - Verify Subscribe Service page GUI elements")
    public void tc_SS_001_verifyPageGUIElements() {
        log.info(">>> TC_SS_001: Verifying Subscribe Service GUI elements.");

        SubscribeServicePage page = loginAndNavigate();

        Assert.assertTrue(page.isPageLoaded(),
            "TC_SS_001 FAIL: One or more expected GUI elements are missing.");

        log.info("<<< TC_SS_001 PASS: All Subscribe Service GUI elements present.");
    }

    // ── TC_SS_002 ─────────────────────────────────────────────────────

    /**
     * TC_SS_002 | Button
     * Verify Search button populates the case table for Patient ID 12.
     */
    @Test(description = "TC_SS_002 - Verify Search button populates case table")
    public void tc_SS_002_verifySearchPopulatesCaseTable() {
        log.info(">>> TC_SS_002: Searching Patient ID: " + ConfigReader.getTestPatientId());

        SubscribeServicePage page = loginAndNavigate();
        page.searchPatient(ConfigReader.getTestPatientId());

        Assert.assertTrue(page.isCaseTablePopulated(),
            "TC_SS_002 FAIL: Case table was NOT populated after Search for Patient ID "
            + ConfigReader.getTestPatientId());

        log.info("<<< TC_SS_002 PASS: Case table populated after Search.");
    }

    // ── TC_SS_003 ─────────────────────────────────────────────────────

    /**
     * TC_SS_003 | Button
     * Verify Select button auto-fills the Case ID mandatory field.
     */
    @Test(description = "TC_SS_003 - Verify Select button auto-fills Case ID")
    public void tc_SS_003_verifySelectAutoFillsCaseId() {
        log.info(">>> TC_SS_003: Verifying Select button auto-populates Case ID.");

        SubscribeServicePage page = loginAndNavigate();
        page.searchPatient(ConfigReader.getTestPatientId());
        page.selectFirstCaseFromTable();

        String caseId = page.getCaseIdFieldValue();
        Assert.assertFalse(caseId.isEmpty(),
            "TC_SS_003 FAIL: Case ID field was NOT auto-filled after clicking Select.");

        log.info("<<< TC_SS_003 PASS: Case ID auto-filled with: " + caseId);
    }

    // ── TC_SS_004 ─────────────────────────────────────────────────────

    /**
     * TC_SS_004 | Mandatory
     * Verify validation shown when Service field is blank on Subscribe.
     */
    @Test(description = "TC_SS_004 - Verify mandatory validation when Service field is blank")
    public void tc_SS_004_verifyMandatoryValidationServiceBlank() {
        log.info(">>> TC_SS_004: Clicking Subscribe with Service field blank.");

        SubscribeServicePage page = loginAndNavigate();
        page.searchPatient(ConfigReader.getTestPatientId());
        page.selectFirstCaseFromTable();
        // Deliberately skip selectService() — leave it blank
        page.enterStartDate("06/01/2025");
        page.clickSubscribeService();

        String validationMsg = page.getValidationMessage();
        Assert.assertFalse(validationMsg.isEmpty(),
            "TC_SS_004 FAIL: No validation message shown for blank Service field.");

        log.info("<<< TC_SS_004 PASS: Validation shown for blank Service. Msg: '"
                 + validationMsg + "'");
    }

    // ── TC_SS_005 ─────────────────────────────────────────────────────

    /**
     * TC_SS_005 | Mandatory
     * Verify validation shown when Service Start Date is blank on Subscribe.
     */
    @Test(description = "TC_SS_005 - Verify mandatory validation when Start Date is blank")
    public void tc_SS_005_verifyMandatoryValidationStartDateBlank() {
        log.info(">>> TC_SS_005: Clicking Subscribe with Start Date blank.");

        SubscribeServicePage page = loginAndNavigate();
        page.searchPatient(ConfigReader.getTestPatientId());
        page.selectFirstCaseFromTable();
        page.selectService("Blood Request");
        // Deliberately skip enterStartDate() — leave it blank
        page.clickSubscribeService();

        String validationMsg = page.getValidationMessage();
        Assert.assertFalse(validationMsg.isEmpty(),
            "TC_SS_005 FAIL: No validation message shown for blank Start Date.");

        log.info("<<< TC_SS_005 PASS: Validation shown for blank Start Date. Msg: '"
                 + validationMsg + "'");
    }

    // ── TC_SS_006 ─────────────────────────────────────────────────────

    /**
     * TC_SS_006 | Valid
     * Verify successful subscription creation for Blood Request service.
     */
    @Test(description = "TC_SS_006 - Verify successful subscription creation")
    public void tc_SS_006_verifySuccessfulSubscriptionCreation() {
        log.info(">>> TC_SS_006: Creating Blood Request subscription for Patient "
                 + ConfigReader.getTestPatientId());

        SubscribeServicePage page = loginAndNavigate();
        page.searchPatient(ConfigReader.getTestPatientId());
        page.selectFirstCaseFromTable();
        page.selectService("Blood Request");
        page.enterStartDate("06/01/2025");
        page.clickSubscribeService();

        Assert.assertTrue(page.isSuccessMessageDisplayed(),
            "TC_SS_006 FAIL: Success/confirmation message NOT shown after subscription.");

        log.info("<<< TC_SS_006 PASS: Subscription created successfully.");
    }
}
