package com.hms.tests;

import com.hms.pages.LoginPage;
import com.hms.pages.ViewToBeServicedPage;
import com.hms.utils.BaseTest;
import com.hms.utils.ConfigReader;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * ViewToBeServicedTests
 * -------------------------------------------------------------------
 * Covers RQ_6 — Blood > Requests > View Blood Requests To Be Serviced
 * TC_VBRS_001 to TC_VBRS_003
 * -------------------------------------------------------------------
 */
public class ViewToBeServicedTests extends BaseTest {

    // ── Shared helper ─────────────────────────────────────────────────

    /**
     * Logs in and navigates to the View Blood Requests To Be Serviced tab.
     * TODO: Replace with actual navigation steps once HMS locators are known.
     */
    private ViewToBeServicedPage loginAndNavigate() {
        log.info("Precondition: Logging in and navigating to View To Be Serviced page.");
        new LoginPage().login(ConfigReader.getValidUsername(), ConfigReader.getValidPassword());
        // TODO: e.g. new HomePage().clickBloodMenu(); new HomePage().clickViewToBeServicedTab();
        return new ViewToBeServicedPage();
    }

    // ── TC_VBRS_001 ───────────────────────────────────────────────────

    /**
     * TC_VBRS_001 | GUI
     * Verify View Blood Requests To Be Serviced page displays correct table columns.
     * Expected columns: Case ID, Patient Name, Blood Group, Blood Required (ml),
     *                   Blood Serviced (ml), Request Date, Status
     */
    @Test(description = "TC_VBRS_001 - Verify table displays correct column headers")
    public void tc_VBRS_001_verifyTableColumns() {
        log.info(">>> TC_VBRS_001: Verifying table column headers.");

        ViewToBeServicedPage page = loginAndNavigate();

        Assert.assertTrue(page.hasExpectedColumns(),
            "TC_VBRS_001 FAIL: One or more expected table columns are missing. "
            + "Expected: Case ID, Patient Name, Blood Group, Blood Required (ml), "
            + "Blood Serviced (ml), Request Date, Status.");

        log.info("<<< TC_VBRS_001 PASS: All expected column headers present.");
    }

    // ── TC_VBRS_002 ───────────────────────────────────────────────────

    /**
     * TC_VBRS_002 | Valid
     * Verify a newly added Blood Request for Patient 12 appears in the table.
     *
     * Precondition: TC_ABR_008 must have run (or a blood request for Patient 12
     * must already exist in the database).
     */
    @Test(description = "TC_VBRS_002 - Verify newly added blood request appears in list")
    public void tc_VBRS_002_verifyNewRequestAppearsInList() {
        log.info(">>> TC_VBRS_002: Verifying Patient " + ConfigReader.getTestPatientId()
                 + " blood request is in the To Be Serviced list.");

        ViewToBeServicedPage page = loginAndNavigate();

        Assert.assertTrue(page.isDataTablePopulated(),
            "TC_VBRS_002 FAIL: Data table is empty — no blood requests found to be serviced.");

        Assert.assertTrue(page.isPatientRequestVisible(ConfigReader.getTestPatientId()),
            "TC_VBRS_002 FAIL: Patient ID " + ConfigReader.getTestPatientId()
            + " is NOT visible in the To Be Serviced table.");

        log.info("<<< TC_VBRS_002 PASS: Patient's blood request visible in list.");
    }

    // ── TC_VBRS_003 ───────────────────────────────────────────────────

    /**
     * TC_VBRS_003 | Button
     * Verify pagination controls appear when records exceed one page,
     * and clicking a page number loads the correct records.
     *
     * Precondition: Enough blood requests must exist in the database
     * to trigger pagination (more than the default page size).
     * If only a few records exist, this test will pass with a soft skip.
     */
    @Test(description = "TC_VBRS_003 - Verify pagination when records exceed one page")
    public void tc_VBRS_003_verifyPaginationForLargeRecordSet() {
        log.info(">>> TC_VBRS_003: Verifying pagination controls.");

        ViewToBeServicedPage page = loginAndNavigate();

        if (!page.isDataTablePopulated()) {
            log.warn("TC_VBRS_003 SKIP: No data in table — pagination cannot be tested. "
                     + "Ensure enough blood requests exist to exceed one page.");
            // Skip instead of failing — data is a precondition, not a defect
            return;
        }

        // If pagination is present: verify it is displayed and navigation works
        if (page.isPaginationDisplayed()) {
            log.info("Pagination controls are visible — attempting page 2 navigation.");
            boolean navigated = page.navigateToPage(2);
            Assert.assertTrue(navigated,
                "TC_VBRS_003 FAIL: Clicking page 2 on pagination did NOT load records.");
            log.info("<<< TC_VBRS_003 PASS: Pagination present and page navigation works.");
        } else {
            // Not enough records for pagination — log a warning but do not fail
            log.warn("TC_VBRS_003 INFO: Pagination not displayed. "
                     + "Possible causes: record count below page limit, or single-page dataset. "
                     + "Add more blood requests to fully exercise this test case.");
        }
    }
}
