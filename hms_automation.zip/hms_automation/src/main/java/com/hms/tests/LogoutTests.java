package com.hms.tests;

import com.hms.pages.HomePage;
import com.hms.pages.LoginPage;
import com.hms.utils.BaseTest;
import com.hms.utils.ConfigReader;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * LogoutTests
 * -------------------------------------------------------------------
 * Covers RQ_2 — Logout (TC_Logout_001 to TC_Logout_003)
 *
 * Each test logs in first (using valid credentials) because logout
 * tests require an authenticated session as a precondition.
 * -------------------------------------------------------------------
 */
public class LogoutTests extends BaseTest {

    // ── TC_Logout_001 ─────────────────────────────────────────────────

    /**
     * TC_Logout_001 | GUI
     * Verify Logout link is visible on the home page after login.
     *
     * Note: TC says "every page" — verifying on home page as representative.
     * Extend to other pages (Subscribe Service, Blood Requests) if needed.
     */
    @Test(description = "TC_Logout_001 - Verify Logout link is visible after login")
    public void tc_Logout_001_verifyLogoutLinkVisibleAfterLogin() {
        log.info(">>> TC_Logout_001: Checking Logout link visibility after login.");

        // Precondition: login with valid credentials
        LoginPage loginPage = new LoginPage();
        loginPage.login(ConfigReader.getValidUsername(), ConfigReader.getValidPassword());

        HomePage homePage = new HomePage();
        Assert.assertTrue(homePage.isLogoutLinkVisible(),
            "TC_Logout_001 FAIL: Logout link is NOT visible after successful login.");

        log.info("<<< TC_Logout_001 PASS: Logout link is visible on the home page.");
    }

    // ── TC_Logout_002 ─────────────────────────────────────────────────

    /**
     * TC_Logout_002 | Valid
     * Verify clicking Logout clears the session and redirects to the login page.
     */
    @Test(description = "TC_Logout_002 - Verify Logout redirects to login page")
    public void tc_Logout_002_verifyLogoutClearsSessionAndRedirects() {
        log.info(">>> TC_Logout_002: Logging out and verifying redirect to login page.");

        // Precondition: login
        LoginPage loginPage = new LoginPage();
        loginPage.login(ConfigReader.getValidUsername(), ConfigReader.getValidPassword());

        HomePage homePage = new HomePage();
        Assert.assertTrue(homePage.isLoaded(),
            "TC_Logout_002 SETUP FAIL: Login did not succeed — cannot test logout.");

        // Action: click Logout
        homePage.clickLogout();

        // Assertion: should be back on login page
        Assert.assertTrue(homePage.isRedirectedToLogin(),
            "TC_Logout_002 FAIL: User was NOT redirected to the Login page after Logout.");

        log.info("<<< TC_Logout_002 PASS: Logout successful, redirected to Login page.");
    }

    // ── TC_Logout_003 ─────────────────────────────────────────────────

    /**
     * TC_Logout_003 | Valid
     * Verify browser Back button after logout does NOT allow access to secured pages.
     */
    @Test(description = "TC_Logout_003 - Verify Back button after logout does not restore session")
    public void tc_Logout_003_verifyBackButtonAfterLogoutDeniesAccess() {
        log.info(">>> TC_Logout_003: Checking back-navigation after logout.");

        // Step 1: Login
        LoginPage loginPage = new LoginPage();
        loginPage.login(ConfigReader.getValidUsername(), ConfigReader.getValidPassword());

        HomePage homePage = new HomePage();
        Assert.assertTrue(homePage.isLoaded(),
            "TC_Logout_003 SETUP FAIL: Login did not succeed.");

        // Step 2: Logout
        homePage.clickLogout();
        Assert.assertTrue(homePage.isRedirectedToLogin(),
            "TC_Logout_003 SETUP FAIL: Logout did not redirect to login page.");

        // Step 3: Press browser Back
        homePage.navigateBack();

        // Assertion: user must still be on (or redirected back to) login page
        // The app should not restore the secured session via browser history
        Assert.assertTrue(homePage.isRedirectedToLogin(),
            "TC_Logout_003 FAIL: Back button restored access to a secured page after logout.");

        log.info("<<< TC_Logout_003 PASS: Back button after logout correctly denied access.");
    }
}
