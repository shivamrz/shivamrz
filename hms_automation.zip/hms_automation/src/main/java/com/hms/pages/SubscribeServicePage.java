package com.hms.pages;

import com.hms.utils.ConfigReader;
import com.hms.utils.DriverSetup;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * SubscribeServicePage — Page Object Model
 * -------------------------------------------------------------------
 * Covers: Patient > Subscribe Service tab (RQ_3, TC_SS_001 to TC_SS_006)
 *
 * Page elements:
 *   PatientID field | Search button | Case table (with Select per row)
 *   Case ID mandatory field | Service dropdown | Service Charge field
 *   Service Start Date field | Subscribe Service button | Reset button
 * -------------------------------------------------------------------
 */
public class SubscribeServicePage {

    private static final Logger log = LogManager.getLogger(SubscribeServicePage.class);

    private final WebDriver driver;
    private final WebDriverWait wait;

    // ── WebElements ───────────────────────────────────────────────────
    // NOTE: Update locator IDs/names to match the actual HMS page source.

    @FindBy(id = "txtPatientId")
    private WebElement patientIdField;

    @FindBy(id = "btnSearch")
    private WebElement searchButton;

    // Case ID mandatory input (auto-filled by Select button in table)
    @FindBy(id = "txtCaseId")
    private WebElement caseIdField;

    // Service dropdown
    @FindBy(id = "ddlService")
    private WebElement serviceDropdown;

    // Service Charge field (default 0)
    @FindBy(id = "txtServiceCharge")
    private WebElement serviceChargeField;

    // Service Start Date field
    @FindBy(id = "txtStartDate")
    private WebElement startDateField;

    @FindBy(id = "btnSubscribeService")
    private WebElement subscribeServiceButton;

    @FindBy(id = "btnReset")
    private WebElement resetButton;

    // Case table container — used to assert it is populated after Search
    @FindBy(id = "tblCases")
    private WebElement caseTable;

    // ── Constructor ───────────────────────────────────────────────────

    public SubscribeServicePage() {
        this.driver = DriverSetup.getDriver();
        this.wait = new WebDriverWait(driver, ConfigReader.getExplicitWait());
        PageFactory.initElements(driver, this);
        log.info("SubscribeServicePage initialised.");
    }

    // ── Action Methods ────────────────────────────────────────────────

    /** Enters patient ID and clicks Search. */
    public void searchPatient(String patientId) {
        log.info("Searching for Patient ID: " + patientId);
        patientIdField.clear();
        patientIdField.sendKeys(patientId);
        searchButton.click();
    }

    /**
     * Clicks the 'Select' button on the first row of the case table.
     * This auto-fills the Case ID mandatory field.
     * TC_SS_003: verifies auto-population of Case ID.
     *
     * NOTE: Update the locator to match the actual 'Select' button/link in table rows.
     */
    public void selectFirstCaseFromTable() {
        log.info("Clicking Select on first case table row.");
        // Adjust this selector — common patterns: button, anchor, input inside a <td>
        By selectButtonLocator = By.cssSelector("#tblCases tr:nth-child(2) input[value='Select'], " +
                                                "#tblCases tr:nth-child(2) a[href*='Select']");
        wait.until(ExpectedConditions.elementToBeClickable(selectButtonLocator));
        driver.findElement(selectButtonLocator).click();
    }

    /** Selects a service by visible text from the Service dropdown. */
    public void selectService(String serviceText) {
        log.info("Selecting service: " + serviceText);
        wait.until(ExpectedConditions.elementToBeClickable(serviceDropdown));
        new Select(serviceDropdown).selectByVisibleText(serviceText);
    }

    /** Enters the service start date (format: depends on HMS, e.g. "06/01/2025"). */
    public void enterStartDate(String date) {
        log.info("Entering Start Date: " + date);
        startDateField.clear();
        startDateField.sendKeys(date);
    }

    /** Clicks the Subscribe Service button. */
    public void clickSubscribeService() {
        log.info("Clicking Subscribe Service button.");
        subscribeServiceButton.click();
    }

    /** Clicks the Reset button. */
    public void clickReset() {
        log.info("Clicking Reset button.");
        resetButton.click();
    }

    // ── Verification / Query Methods ──────────────────────────────────

    /**
     * TC_SS_001: All GUI elements must be present on the Subscribe Service page.
     */
    public boolean isPageLoaded() {
        boolean loaded = patientIdField.isDisplayed()
                && searchButton.isDisplayed()
                && caseIdField.isDisplayed()
                && serviceDropdown.isDisplayed()
                && startDateField.isDisplayed()
                && subscribeServiceButton.isDisplayed()
                && resetButton.isDisplayed();
        log.info("SubscribeServicePage fully loaded: " + loaded);
        return loaded;
    }

    /**
     * TC_SS_002: Case table should be populated after search.
     */
    public boolean isCaseTablePopulated() {
        try {
            wait.until(ExpectedConditions.visibilityOf(caseTable));
            // At least one data row beyond the header row
            boolean populated = driver.findElements(
                By.cssSelector("#tblCases tr")).size() > 1;
            log.info("Case table populated: " + populated);
            return populated;
        } catch (Exception e) {
            log.warn("Case table not populated: " + e.getMessage());
            return false;
        }
    }

    /**
     * TC_SS_003: Case ID field should have a value after Select is clicked.
     */
    public String getCaseIdFieldValue() {
        String val = caseIdField.getAttribute("value");
        log.info("Case ID field value: '" + val + "'");
        return val;
    }

    /**
     * Returns the validation/error message text shown on this page.
     * TC_SS_004, TC_SS_005: mandatory field checks.
     *
     * NOTE: Update locator to the actual alert/error element on Subscribe Service page.
     */
    public String getValidationMessage() {
        By alertLocator = By.cssSelector(".alert, .error-message, #lblError, span[class*='error']");
        try {
            WebElement alert = wait.until(
                ExpectedConditions.visibilityOfElementLocated(alertLocator));
            String msg = alert.getText().trim();
            log.info("Validation message: '" + msg + "'");
            return msg;
        } catch (Exception e) {
            log.warn("No validation message found.");
            return "";
        }
    }

    /**
     * TC_SS_006: Returns true if a success/confirmation message is shown.
     *
     * NOTE: Update locator to the actual success message element on HMS.
     */
    public boolean isSuccessMessageDisplayed() {
        By successLocator = By.cssSelector(".success, .alert-success, #lblSuccess, span[class*='success']");
        try {
            WebElement msg = wait.until(
                ExpectedConditions.visibilityOfElementLocated(successLocator));
            boolean visible = msg.isDisplayed();
            log.info("Success message displayed: " + visible + " | Text: " + msg.getText());
            return visible;
        } catch (Exception e) {
            log.warn("Success message not found.");
            return false;
        }
    }
}
