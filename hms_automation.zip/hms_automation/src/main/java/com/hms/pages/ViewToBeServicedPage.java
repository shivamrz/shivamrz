package com.hms.pages;

import com.hms.utils.ConfigReader;
import com.hms.utils.DriverSetup;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.List;

/**
 * ViewToBeServicedPage — Page Object Model
 * -------------------------------------------------------------------
 * Covers: Blood > Requests > View Blood Requests To Be Serviced (RQ_6)
 * TC_VBRS_001: Verify table columns
 * TC_VBRS_002: Newly added request appears in list
 * TC_VBRS_003: Pagination when records exceed page limit
 * -------------------------------------------------------------------
 */
public class ViewToBeServicedPage {

    private static final Logger log = LogManager.getLogger(ViewToBeServicedPage.class);

    private final WebDriver driver;
    private final WebDriverWait wait;

    // ── Expected Column Headers ───────────────────────────────────────

    public static final String[] EXPECTED_COLUMNS = {
        "Case ID", "Patient Name", "Blood Group",
        "Blood Required (ml)", "Blood Serviced (ml)", "Request Date", "Status"
    };

    // ── WebElements ───────────────────────────────────────────────────
    // NOTE: Update IDs/names to match actual HMS page source.

    // Main data table
    @FindBy(id = "tblToBeServiced")
    private WebElement dataTable;

    // Pagination container — present when records span multiple pages
    // Adjust selector to match actual pagination element on HMS
    @FindBy(css = ".pagination, #divPagination, ul.pager")
    private WebElement paginationContainer;

    // ── Constructor ───────────────────────────────────────────────────

    public ViewToBeServicedPage() {
        this.driver = DriverSetup.getDriver();
        this.wait = new WebDriverWait(driver, ConfigReader.getExplicitWait());
        PageFactory.initElements(driver, this);
        log.info("ViewToBeServicedPage initialised.");
    }

    // ── Verification / Query Methods ──────────────────────────────────

    /**
     * TC_VBRS_001: Returns true if the table is displayed with the expected columns.
     * Reads the header row and checks each expected column header is present.
     */
    public boolean hasExpectedColumns() {
        try {
            wait.until(ExpectedConditions.visibilityOf(dataTable));

            // Read all <th> or header <td> elements in the first row
            List<WebElement> headers = driver.findElements(
                By.cssSelector("#tblToBeServiced th, #tblToBeServiced tr:first-child td"));

            // Collect header text into a list for comparison
            StringBuilder found = new StringBuilder();
            for (WebElement h : headers) {
                found.append(h.getText().trim()).append("|");
            }
            String headerRow = found.toString();
            log.info("Table headers found: " + headerRow);

            // Check every expected column is present
            for (String expected : EXPECTED_COLUMNS) {
                if (!headerRow.contains(expected)) {
                    log.warn("Expected column NOT found: '" + expected + "'");
                    return false;
                }
            }
            log.info("All expected columns present.");
            return true;

        } catch (Exception e) {
            log.error("Column verification failed: " + e.getMessage());
            return false;
        }
    }

    /**
     * TC_VBRS_002: Returns true if the table has at least one data row
     * (i.e. the newly added request appears in the list).
     */
    public boolean isDataTablePopulated() {
        try {
            wait.until(ExpectedConditions.visibilityOf(dataTable));
            int rowCount = driver.findElements(
                By.cssSelector("#tblToBeServiced tr")).size();
            // > 1 means at least one data row beyond the header
            boolean populated = rowCount > 1;
            log.info("Data table populated: " + populated + " | Row count: " + rowCount);
            return populated;
        } catch (Exception e) {
            log.warn("Data table check failed: " + e.getMessage());
            return false;
        }
    }

    /**
     * TC_VBRS_002: Returns true if a row matching the given patient ID exists in the table.
     * Useful to verify a specific patient's request is visible.
     */
    public boolean isPatientRequestVisible(String patientId) {
        try {
            String bodyText = dataTable.getText();
            boolean visible = bodyText.contains(patientId);
            log.info("Patient ID '" + patientId + "' visible in table: " + visible);
            return visible;
        } catch (Exception e) {
            log.warn("Could not verify patient row: " + e.getMessage());
            return false;
        }
    }

    /**
     * TC_VBRS_003: Returns true if pagination controls are visible.
     */
    public boolean isPaginationDisplayed() {
        try {
            boolean displayed = paginationContainer.isDisplayed();
            log.info("Pagination controls displayed: " + displayed);
            return displayed;
        } catch (Exception e) {
            log.warn("Pagination element not found: " + e.getMessage());
            return false;
        }
    }

    /**
     * TC_VBRS_003: Clicks a pagination page number and returns the first cell
     * of the first data row on that page — used to verify navigation works.
     *
     * @param pageNumber 1-based page number to click
     */
    public boolean navigateToPage(int pageNumber) {
        try {
            // Adjust selector: some paginations use <a> tags, some use <li> with <a>
            By pageLink = By.cssSelector(
                ".pagination a[data-page='" + pageNumber + "'], " +
                "ul.pager li:nth-child(" + pageNumber + ") a, " +
                "#divPagination a:nth-child(" + pageNumber + ")");
            WebElement page = wait.until(ExpectedConditions.elementToBeClickable(pageLink));
            page.click();
            log.info("Navigated to pagination page: " + pageNumber);
            // Brief wait for the table to reload
            wait.until(ExpectedConditions.visibilityOf(dataTable));
            return true;
        } catch (Exception e) {
            log.warn("Could not navigate to page " + pageNumber + ": " + e.getMessage());
            return false;
        }
    }
}
