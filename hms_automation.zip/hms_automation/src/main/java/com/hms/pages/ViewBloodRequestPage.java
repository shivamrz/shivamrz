package com.hms.pages;

import com.hms.utils.ConfigReader;
import com.hms.utils.DriverSetup;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * ViewBloodRequestPage — Page Object Model
 * -------------------------------------------------------------------
 * Covers: Blood > Requests > View Blood Requests tab (RQ_5, TC_VBR_001..005)
 *
 * Page elements:
 *   PatientID field | Search button | Case table with Select
 *   CaseID mandatory field | Fetch Blood Requests button
 *   Results table | Reset button
 * -------------------------------------------------------------------
 */
public class ViewBloodRequestPage {

    private static final Logger log = LogManager.getLogger(ViewBloodRequestPage.class);

    private final WebDriver driver;
    private final WebDriverWait wait;

    // ── WebElements ───────────────────────────────────────────────────
    // NOTE: Update IDs/names to match actual HMS page source.

    @FindBy(id = "txtPatientId")
    private WebElement patientIdField;

    @FindBy(id = "btnSearch")
    private WebElement searchButton;

    @FindBy(id = "txtCaseId")
    private WebElement caseIdField;

    @FindBy(id = "btnFetchBloodRequests")
    private WebElement fetchBloodRequestsButton;

    // Results table — populated after Fetch Blood Requests
    @FindBy(id = "tblBloodRequests")
    private WebElement resultsTable;

    // Case table — populated after Search
    @FindBy(id = "tblCases")
    private WebElement caseTable;

    @FindBy(id = "btnReset")
    private WebElement resetButton;

    // ── Constructor ───────────────────────────────────────────────────

    public ViewBloodRequestPage() {
        this.driver = DriverSetup.getDriver();
        this.wait = new WebDriverWait(driver, ConfigReader.getExplicitWait());
        PageFactory.initElements(driver, this);
        log.info("ViewBloodRequestPage initialised.");
    }

    // ── Action Methods ────────────────────────────────────────────────

    /** Enters patient ID and clicks Search. */
    public void searchPatient(String patientId) {
        log.info("Searching Patient ID: " + patientId);
        patientIdField.clear();
        patientIdField.sendKeys(patientId);
        searchButton.click();
    }

    /**
     * Clicks Select on the first row of the case table.
     * Auto-fills CaseID field.
     */
    public void selectFirstCaseFromTable() {
        log.info("Selecting first case row.");
        By selectBtnLocator = By.cssSelector(
            "#tblCases tr:nth-child(2) input[value='Select'], " +
            "#tblCases tr:nth-child(2) a[href*='Select']");
        wait.until(ExpectedConditions.elementToBeClickable(selectBtnLocator));
        driver.findElement(selectBtnLocator).click();
    }

    /** Clicks the Fetch Blood Requests button. */
    public void clickFetchBloodRequests() {
        log.info("Clicking Fetch Blood Requests button.");
        fetchBloodRequestsButton.click();
    }

    /** Clicks the Reset button. */
    public void clickReset() {
        log.info("Clicking Reset button.");
        resetButton.click();
    }

    // ── Verification / Query Methods ──────────────────────────────────

    /**
     * TC_VBR_001: All expected GUI elements are present on the page.
     */
    public boolean isPageLoaded() {
        boolean loaded = patientIdField.isDisplayed()
                && searchButton.isDisplayed()
                && caseIdField.isDisplayed()
                && fetchBloodRequestsButton.isDisplayed()
                && resetButton.isDisplayed();
        log.info("ViewBloodRequestPage fully loaded: " + loaded);
        return loaded;
    }

    /**
     * TC_VBR_002: Case table should have rows after Search.
     */
    public boolean isCaseTablePopulated() {
        try {
            wait.until(ExpectedConditions.visibilityOf(caseTable));
            boolean populated = driver.findElements(
                By.cssSelector("#tblCases tr")).size() > 1;
            log.info("Case table populated: " + populated);
            return populated;
        } catch (Exception e) {
            log.warn("Case table not populated: " + e.getMessage());
            return false;
        }
    }

    /**
     * TC_VBR_003: Results table should show records after Fetch Blood Requests.
     */
    public boolean isResultsTablePopulated() {
        try {
            wait.until(ExpectedConditions.visibilityOf(resultsTable));
            boolean populated = driver.findElements(
                By.cssSelector("#tblBloodRequests tr")).size() > 1;
            log.info("Results table populated: " + populated);
            return populated;
        } catch (Exception e) {
            log.warn("Results table not populated: " + e.getMessage());
            return false;
        }
    }

    /**
     * TC_VBR_004: Returns true when results table is empty or shows no records message.
     * Used for patients with no blood requests.
     */
    public boolean isResultsTableEmpty() {
        try {
            // Option 1: Table has only header row (no data rows)
            int rowCount = driver.findElements(
                By.cssSelector("#tblBloodRequests tr")).size();
            if (rowCount <= 1) {
                log.info("Results table empty — row count: " + rowCount);
                return true;
            }
            // Option 2: 'No records found' text is present
            String bodyText = driver.findElement(By.tagName("body")).getText();
            boolean noRecords = bodyText.contains("No records found")
                             || bodyText.contains("No data")
                             || rowCount == 0;
            log.info("Results table empty check: " + noRecords);
            return noRecords;
        } catch (Exception e) {
            log.warn("Could not verify results table empty state: " + e.getMessage());
            return false;
        }
    }

    /**
     * TC_VBR_005: After Reset, all input fields should be cleared.
     */
    public boolean areFieldsCleared() {
        String patientVal = patientIdField.getAttribute("value");
        String caseVal    = caseIdField.getAttribute("value");
        boolean cleared = (patientVal == null || patientVal.isEmpty())
                       && (caseVal    == null || caseVal.isEmpty());
        log.info("Fields cleared after Reset: " + cleared
                 + " | PatientID='" + patientVal + "' CaseID='" + caseVal + "'");
        return cleared;
    }
}
