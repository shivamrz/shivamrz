package com.hms.pages;

import com.hms.utils.ConfigReader;
import com.hms.utils.DriverSetup;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * HomePage — Page Object Model
 * -------------------------------------------------------------------
 * Represents the HMS dashboard/home page reached after successful login.
 * Also exposes the navigation elements shared across all pages
 * (Logout link, top nav menu items).
 *
 * SDET Best Practice:
 *   - Shared navigation elements live here, not duplicated across pages.
 *   - isLoaded() gives tests a clean assertion point post-login.
 * -------------------------------------------------------------------
 */
public class HomePage {

    private static final Logger log = LogManager.getLogger(HomePage.class);

    private final WebDriver driver;
    private final WebDriverWait wait;

    // ── WebElements ───────────────────────────────────────────────────

    // Logout link — visible on every page after login
    // NOTE: Update locator to match actual logout element on HMS (linkText / id / css)
    @FindBy(linkText = "Logout")
    private WebElement logoutLink;

    // Dashboard/welcome element — confirms successful login
    // NOTE: Update to a stable element that only appears after login
    @FindBy(css = "body")
    private WebElement pageBody;

    // ── Constructor ───────────────────────────────────────────────────

    public HomePage() {
        this.driver = DriverSetup.getDriver();
        this.wait = new WebDriverWait(driver, ConfigReader.getExplicitWait());
        PageFactory.initElements(driver, this);
        log.info("HomePage initialised.");
    }

    // ── Action Methods ────────────────────────────────────────────────

    /**
     * Clicks the Logout link.
     * TC_Logout_002: session should clear and redirect to login page.
     */
    public void clickLogout() {
        log.info("Clicking Logout link.");
        wait.until(ExpectedConditions.elementToBeClickable(logoutLink));
        logoutLink.click();
    }

    // ── Verification / Query Methods ──────────────────────────────────

    /**
     * Returns true if the Logout link is visible on the current page.
     * TC_Logout_001: logout must be accessible from every page.
     */
    public boolean isLogoutLinkVisible() {
        try {
            wait.until(ExpectedConditions.visibilityOf(logoutLink));
            boolean visible = logoutLink.isDisplayed();
            log.info("Logout link visible: " + visible);
            return visible;
        } catch (Exception e) {
            log.warn("Logout link not visible: " + e.getMessage());
            return false;
        }
    }

    /**
     * Returns true if the browser has navigated away from the login page
     * — used to assert successful login landed on dashboard.
     */
    public boolean isLoaded() {
        String url = driver.getCurrentUrl();
        boolean loaded = !url.contains("LoginPage");
        log.info("HomePage loaded: " + loaded + " | URL: " + url);
        return loaded;
    }

    /**
     * Returns true if the browser is back on the login page.
     * TC_Logout_002: after logout, URL must contain LoginPage.
     */
    public boolean isRedirectedToLogin() {
        String url = driver.getCurrentUrl();
        boolean onLogin = url.contains("LoginPage");
        log.info("Redirected to login: " + onLogin + " | URL: " + url);
        return onLogin;
    }

    /**
     * Simulates pressing the browser Back button.
     * TC_Logout_003: back-navigation after logout must not restore secured page.
     */
    public void navigateBack() {
        log.info("Pressing browser Back button.");
        driver.navigate().back();
    }
}
