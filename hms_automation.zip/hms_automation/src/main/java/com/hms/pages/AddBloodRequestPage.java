package com.hms.pages;

import com.hms.utils.ConfigReader;
import com.hms.utils.DriverSetup;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * AddBloodRequestPage — Page Object Model
 * -------------------------------------------------------------------
 * Covers: Blood > Requests > Add Blood Requests tab (RQ_4, TC_ABR_001..009)
 *
 * Page elements:
 *   PatientID field | Search button | Case table with Select
 *   CaseID mandatory field | Fetch Service Subscription button
 *   Service Subscription dropdown | Unit Size dropdown
 *   No Of Units dropdown | Add Blood Requests button | Reset button
 * -------------------------------------------------------------------
 */
public class AddBloodRequestPage {

    private static final Logger log = LogManager.getLogger(AddBloodRequestPage.class);

    private final WebDriver driver;
    private final WebDriverWait wait;

    // ── WebElements ───────────────────────────────────────────────────
    // NOTE: Update IDs/names to match actual HMS page source.

    @FindBy(id = "txtPatientId")
    private WebElement patientIdField;

    @FindBy(id = "btnSearch")
    private WebElement searchButton;

    // Case ID — auto-filled when user clicks Select in table
    @FindBy(id = "txtCaseId")
    private WebElement caseIdField;

    @FindBy(id = "btnFetchServiceSubscription")
    private WebElement fetchServiceSubscriptionButton;

    // Dropdown populated by Fetch Service Subscription
    @FindBy(id = "ddlServiceSubscription")
    private WebElement serviceSubscriptionDropdown;

    @FindBy(id = "ddlUnitSize")
    private WebElement unitSizeDropdown;

    @FindBy(id = "ddlNoOfUnits")
    private WebElement noOfUnitsDropdown;

    @FindBy(id = "btnAddBloodRequest")
    private WebElement addBloodRequestButton;

    @FindBy(id = "btnReset")
    private WebElement resetButton;

    // Case table — asserted after Search
    @FindBy(id = "tblCases")
    private WebElement caseTable;

    // ── Constructor ───────────────────────────────────────────────────

    public AddBloodRequestPage() {
        this.driver = DriverSetup.getDriver();
        this.wait = new WebDriverWait(driver, ConfigReader.getExplicitWait());
        PageFactory.initElements(driver, this);
        log.info("AddBloodRequestPage initialised.");
    }

    // ── Action Methods ────────────────────────────────────────────────

    /** Enters patient ID and clicks Search to populate case table. */
    public void searchPatient(String patientId) {
        log.info("Searching Patient ID: " + patientId);
        patientIdField.clear();
        patientIdField.sendKeys(patientId);
        searchButton.click();
    }

    /**
     * Clicks Select on the first row of the case table.
     * Auto-fills the CaseID mandatory field.
     * TC_ABR_003.
     */
    public void selectFirstCaseFromTable() {
        log.info("Selecting first case from table.");
        By selectBtnLocator = By.cssSelector(
            "#tblCases tr:nth-child(2) input[value='Select'], " +
            "#tblCases tr:nth-child(2) a[href*='Select']");
        wait.until(ExpectedConditions.elementToBeClickable(selectBtnLocator));
        driver.findElement(selectBtnLocator).click();
    }

    /** Clicks the Fetch Service Subscription button. */
    public void clickFetchServiceSubscription() {
        log.info("Clicking Fetch Service Subscription.");
        fetchServiceSubscriptionButton.click();
    }

    /** Selects a service from the Service Subscription dropdown by visible text. */
    public void selectServiceSubscription(String serviceText) {
        log.info("Selecting service subscription: " + serviceText);
        wait.until(ExpectedConditions.elementToBeClickable(serviceSubscriptionDropdown));
        new Select(serviceSubscriptionDropdown).selectByVisibleText(serviceText);
    }

    /** Selects Unit Size by visible text (e.g. "500ml"). */
    public void selectUnitSize(String unitSize) {
        log.info("Selecting Unit Size: " + unitSize);
        new Select(unitSizeDropdown).selectByVisibleText(unitSize);
    }

    /** Selects No Of Units by visible text (e.g. "2"). */
    public void selectNoOfUnits(String units) {
        log.info("Selecting No Of Units: " + units);
        new Select(noOfUnitsDropdown).selectByVisibleText(units);
    }

    /** Clicks Add Blood Requests button to submit the form. */
    public void clickAddBloodRequest() {
        log.info("Clicking Add Blood Requests button.");
        addBloodRequestButton.click();
    }

    /** Clicks Reset button to clear the form. */
    public void clickReset() {
        log.info("Clicking Reset button.");
        resetButton.click();
    }

    // ── Verification / Query Methods ──────────────────────────────────

    /**
     * TC_ABR_001: All expected GUI elements are present.
     */
    public boolean isPageLoaded() {
        boolean loaded = patientIdField.isDisplayed()
                && searchButton.isDisplayed()
                && caseIdField.isDisplayed()
                && fetchServiceSubscriptionButton.isDisplayed()
                && serviceSubscriptionDropdown.isDisplayed()
                && unitSizeDropdown.isDisplayed()
                && noOfUnitsDropdown.isDisplayed()
                && addBloodRequestButton.isDisplayed()
                && resetButton.isDisplayed();
        log.info("AddBloodRequestPage fully loaded: " + loaded);
        return loaded;
    }

    /**
     * TC_ABR_002: Case table should have rows after Search.
     */
    public boolean isCaseTablePopulated() {
        try {
            wait.until(ExpectedConditions.visibilityOf(caseTable));
            boolean populated = driver.findElements(
                By.cssSelector("#tblCases tr")).size() > 1;
            log.info("Case table populated: " + populated);
            return populated;
        } catch (Exception e) {
            log.warn("Case table not populated: " + e.getMessage());
            return false;
        }
    }

    /**
     * TC_ABR_003: CaseID field should be auto-filled after Select.
     */
    public String getCaseIdFieldValue() {
        String val = caseIdField.getAttribute("value");
        log.info("CaseID field value: '" + val + "'");
        return val;
    }

    /**
     * TC_ABR_004: Service Subscription dropdown should have options after Fetch.
     */
    public boolean isServiceSubscriptionDropdownPopulated() {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(serviceSubscriptionDropdown));
            Select select = new Select(serviceSubscriptionDropdown);
            // More than 1 option means it's populated (index 0 is usually the placeholder)
            boolean populated = select.getOptions().size() > 1;
            log.info("Service Subscription dropdown populated: " + populated
                     + " | Options count: " + select.getOptions().size());
            return populated;
        } catch (Exception e) {
            log.warn("Service Subscription dropdown check failed: " + e.getMessage());
            return false;
        }
    }

    /**
     * TC_ABR_005: Returns selected value of Unit Size dropdown.
     */
    public String getSelectedUnitSize() {
        String val = new Select(unitSizeDropdown).getFirstSelectedOption().getText();
        log.info("Selected Unit Size: " + val);
        return val;
    }

    /**
     * TC_ABR_005: Returns selected value of No Of Units dropdown.
     */
    public String getSelectedNoOfUnits() {
        String val = new Select(noOfUnitsDropdown).getFirstSelectedOption().getText();
        log.info("Selected No Of Units: " + val);
        return val;
    }

    /**
     * TC_ABR_006, TC_ABR_007: Returns validation/error message text.
     * NOTE: Update locator to match actual error element on HMS.
     */
    public String getValidationMessage() {
        By alertLocator = By.cssSelector(".alert, .error-message, #lblError, span[class*='error']");
        try {
            WebElement alert = wait.until(
                ExpectedConditions.visibilityOfElementLocated(alertLocator));
            String msg = alert.getText().trim();
            log.info("Validation message: '" + msg + "'");
            return msg;
        } catch (Exception e) {
            log.warn("No validation message found.");
            return "";
        }
    }

    /**
     * TC_ABR_008: Returns true when a success/confirmation message is displayed.
     * NOTE: Update locator to match actual success element on HMS.
     */
    public boolean isSuccessMessageDisplayed() {
        By successLocator = By.cssSelector(".success, .alert-success, #lblSuccess, span[class*='success']");
        try {
            WebElement msg = wait.until(
                ExpectedConditions.visibilityOfElementLocated(successLocator));
            boolean visible = msg.isDisplayed();
            log.info("Success message displayed: " + visible + " | Text: " + msg.getText());
            return visible;
        } catch (Exception e) {
            log.warn("Success message not found.");
            return false;
        }
    }

    /**
     * TC_ABR_009: Returns true when Service Subscription dropdown is empty
     * (no options besides the default placeholder) after Fetch for an unsubscribed case.
     */
    public boolean isServiceSubscriptionDropdownEmpty() {
        try {
            Select select = new Select(serviceSubscriptionDropdown);
            boolean empty = select.getOptions().size() <= 1;
            log.info("Service Subscription dropdown empty: " + empty);
            return empty;
        } catch (Exception e) {
            log.warn("Could not check dropdown state: " + e.getMessage());
            return true; // treat exception as empty (no options available)
        }
    }
}
