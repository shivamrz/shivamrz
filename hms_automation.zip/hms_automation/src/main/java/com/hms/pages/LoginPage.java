package com.hms.pages;

import com.hms.utils.DriverSetup;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hms.utils.ConfigReader;

/**
 * LoginPage — Page Object Model
 * -------------------------------------------------------------------
 * Encapsulates all WebElements and actions for the HMS Login page.
 * Test classes call methods here — they never touch locators directly.
 *
 * SDET Best Practice:
 *   - @FindBy annotations declare locators (PageFactory pattern).
 *   - All actions are wrapped in methods with log statements.
 *   - Explicit wait used only where dynamic behaviour requires it.
 * -------------------------------------------------------------------
 */
public class LoginPage {

    private static final Logger log = LogManager.getLogger(LoginPage.class);

    private final WebDriver driver;
    private final WebDriverWait wait;

    // ── WebElements (PageFactory) ─────────────────────────────────────

    @FindBy(id = "txtUserId")
    private WebElement userIdField;

    @FindBy(id = "txtPassword")
    private WebElement passwordField;

    @FindBy(id = "btnLogin")
    private WebElement loginButton;

    @FindBy(id = "btnReset")
    private WebElement resetButton;

    // Label/heading that confirms we are on the login page
    // Adjust locator if the actual page has a different element
    @FindBy(css = "input[type='password']")
    private WebElement passwordInputType;

    // ── Constructor ───────────────────────────────────────────────────

    public LoginPage() {
        this.driver = DriverSetup.getDriver();
        this.wait = new WebDriverWait(driver, ConfigReader.getExplicitWait());
        // Initialise @FindBy fields
        PageFactory.initElements(driver, this);
        log.info("LoginPage initialised.");
    }

    // ── Action Methods ────────────────────────────────────────────────

    /**
     * Types the given text into the User ID field.
     */
    public void enterUserId(String userId) {
        log.info("Entering User ID: " + userId);
        userIdField.clear();
        userIdField.sendKeys(userId);
    }

    /**
     * Types the given text into the Password field.
     */
    public void enterPassword(String password) {
        log.info("Entering Password: [MASKED]");
        passwordField.clear();
        passwordField.sendKeys(password);
    }

    /**
     * Clicks the Login button.
     */
    public void clickLogin() {
        log.info("Clicking Login button.");
        loginButton.click();
    }

    /**
     * Clicks the Reset button.
     */
    public void clickReset() {
        log.info("Clicking Reset button.");
        resetButton.click();
    }

    /**
     * Full login flow: enter credentials and submit.
     */
    public void login(String userId, String password) {
        enterUserId(userId);
        enterPassword(password);
        clickLogin();
    }

    // ── Verification / Query Methods ──────────────────────────────────

    /**
     * Checks whether the User ID input field is displayed.
     */
    public boolean isUserIdFieldDisplayed() {
        boolean visible = userIdField.isDisplayed();
        log.info("User ID field displayed: " + visible);
        return visible;
    }

    /**
     * Checks whether the Password input field is displayed.
     */
    public boolean isPasswordFieldDisplayed() {
        boolean visible = passwordField.isDisplayed();
        log.info("Password field displayed: " + visible);
        return visible;
    }

    /**
     * Checks whether the Login button is displayed.
     */
    public boolean isLoginButtonDisplayed() {
        boolean visible = loginButton.isDisplayed();
        log.info("Login button displayed: " + visible);
        return visible;
    }

    /**
     * Checks whether the Reset button is displayed.
     */
    public boolean isResetButtonDisplayed() {
        boolean visible = resetButton.isDisplayed();
        log.info("Reset button displayed: " + visible);
        return visible;
    }

    /**
     * Returns true if the password field masks input (type="password").
     * TC_Login_002: password characters must not be visible.
     */
    public boolean isPasswordMasked() {
        String inputType = passwordField.getAttribute("type");
        boolean masked = "password".equalsIgnoreCase(inputType);
        log.info("Password field type: '" + inputType + "' | Masked: " + masked);
        return masked;
    }

    /**
     * Returns the current value of the User ID field.
     * Used to assert the field is empty after Reset.
     */
    public String getUserIdFieldValue() {
        return userIdField.getAttribute("value");
    }

    /**
     * Returns the current value of the Password field.
     * Used to assert the field is empty after Reset.
     */
    public String getPasswordFieldValue() {
        return passwordField.getAttribute("value");
    }

    /**
     * Waits for and returns the validation/error message text shown on the page.
     * Covers both mandatory-field alerts and invalid-credential messages.
     *
     * NOTE: Update the locator below to match the actual alert element on HMS.
     *       Common patterns: alert div, span with class "error", JS alert, etc.
     */
    public String getValidationMessage() {
        // Adjust this By locator to the real alert/error element on the HMS login page
        By alertLocator = By.cssSelector(".alert, .error-message, #lblError, span[class*='error']");
        try {
            WebElement alert = wait.until(
                ExpectedConditions.visibilityOfElementLocated(alertLocator));
            String msg = alert.getText().trim();
            log.info("Validation message found: '" + msg + "'");
            return msg;
        } catch (Exception e) {
            log.warn("No validation message element found with locator: " + alertLocator);
            return "";
        }
    }

    /**
     * Returns true if the browser is still on the login page URL.
     * Used to assert failed login did NOT navigate away.
     */
    public boolean isOnLoginPage() {
        String currentUrl = driver.getCurrentUrl();
        boolean onLogin = currentUrl.contains("LoginPage");
        log.info("Current URL: " + currentUrl + " | On login page: " + onLogin);
        return onLogin;
    }
}
